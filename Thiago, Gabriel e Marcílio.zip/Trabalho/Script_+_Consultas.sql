﻿CREATE SCHEMA BDCAS;

CREATE DOMAIN BDCAS.id AS int;


CREATE TABLE BDCAS.Usuario(
	idUsuario BDCAS.id NOT NULL,
	nomeUsuario VARCHAR(45),
	CONSTRAINT pkUsuario PRIMARY KEY (idUsuario)
);

CREATE TABLE BDCAS.UsuarioComum(
	idUsuario int NOT NULL,
	CONSTRAINT pkUsuarioComum PRIMARY KEY (idUsuario),
	CONSTRAINT fkUsuarioComum FOREIGN KEY (idUsuario) REFERENCES BDCAS.Usuario(idUsuario) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE BDCAS.UsuarioAdministrador(
	idUsuario int NOT NULL,
	login VARCHAR(45) NOT NULL,
	senha CHAR(8) NOT NULL,
	CONSTRAINT pkUsuarioAdministrador PRIMARY KEY (idUsuario),
	CONSTRAINT fkUsuarioAdministrador FOREIGN KEY (idUsuario) REFERENCES BDCAS.Usuario(idUsuario) ON DELETE CASCADE ON UPDATE CASCADE
);



CREATE TABLE BDCAS.Alimento(
	idAlimento BDCAS.id NOT NULL,
	nomeAlimento VARCHAR(45),
	CONSTRAINT pkAlimento PRIMARY KEY(idAlimento)
);


CREATE TABLE BDCAS.LocalizacaoGeografica(
	localizacaoGeografica VARCHAR(45) NOT NULL,
	Alimento_idAlimento int NOT NULL,
	CONSTRAINT pkLocalizacaoGeografica PRIMARY KEY(Alimento_idAlimento),
	CONSTRAINT fkAlimento FOREIGN KEY(Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE BDCAS.ParteAlimentoEstudada(
	Alimento_idAlimento int NOT NULL,
	parteAlimentoEstudada VARCHAR(45) NOT NULL,
	CONSTRAINT pkParteAlimentoEstudada PRIMARY KEY(Alimento_idAlimento),
	CONSTRAINT fkParteAlimentoEstudada FOREIGN KEY(Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE	
);	

CREATE TABLE BDCAS.Informacoes_Botanicas(
	idInformacoes_Botanicas int NOT NULL,
	Alimento_idAlimento int NOT NULL,
	subfamilia VARCHAR(45) NOT NULL,
	tribo VARCHAR(45) NOT NULL,
	subtribo VARCHAR(45) NOT NULL,
	CONSTRAINT pkInformacoes_Botanicas PRIMARY KEY(Alimento_idAlimento, idInformacoes_Botanicas),
	CONSTRAINT fkInformacoes_Botanicas FOREIGN KEY(Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE	

);



CREATE TABLE BDCAS.Referencia_Bibliografica(
	idBibliografia int NOT NULL,
	Alimento_idAlimento int NOT NULL,
	autor VARCHAR(45) NOT NULL,
	dataPublicacao TIMESTAMP NOT NULL,
	fontePublicacao VARCHAR(90) NOT NULL,
	CONSTRAINT pkReferencia_Bibliografica PRIMARY KEY(Alimento_idAlimento, idBibliografia),
	CONSTRAINT fkReferencia_Bibliografica FOREIGN KEY(Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE	

);

CREATE TABLE BDCAS.Nome_Cientifico_Alimento(
	Alimento_idAlimento int NOT NULL,
	nomeBinomial VARCHAR(45) NOT NULL,
	autor VARCHAR(45) NOT NULL,
	especie VARCHAR(45) NOT NULL,
	genero VARCHAR(45) NOT NULL,
	familia VARCHAR(45) NOT NULL,
	ordem VARCHAR(45) NOT NULL,
	filo VARCHAR(45) NOT NULL,
	reino VARCHAR(45) NOT NULL,
	clado VARCHAR(45),
	CONSTRAINT pkNome_Cientifico_Alimento PRIMARY KEY(Alimento_idAlimento, nomeBinomial),
	CONSTRAINT fkNome_Cientifico_Alimento FOREIGN KEY(Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE	

);

CREATE TABLE BDCAS.Substancia(
	idSubstancia int NOT NULL,
	CONSTRAINT pkSubstancia PRIMARY KEY(idSubstancia)
);

CREATE TABLE BDCAS.Nome_Cientifico_Substancia(
    idNome_Cientifico_Substancia int NOT NULL,
    nomeComum VARCHAR(45) NOT NULL,
    nomeSistematico_IUPAC VARCHAR(45) NOT NULL,
    Substancia_idSubstancia int NOT NULL,
    CONSTRAINT pkNome_Cientifico_Substancia PRIMARY KEY(idNome_Cientifico_Substancia),
    CONSTRAINT fkNome_Cientifico_Substancia FOREIGN KEY(Substancia_idSubstancia) REFERENCES BDCAS.Substancia(idSubstancia) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE BDCAS.Descritor (
  idDescritor INT NOT NULL,
  h_bond_acceptr INT NOT NULL,
  h_bond_donors INT NOT NULL,
  massaExata FLOAT NOT NULL,
  aLogP FLOAT NOT NULL,
  mLogP FLOAT NOT NULL,
  LogS FLOAT NOT NULL,
  LogD FLOAT NOT NULL,
  CONSTRAINT pkDescritor PRIMARY KEY(idDescritor)
);


CREATE TABLE BDCAS.Estrutura (
  identifier_InCHl INT NOT NULL,
  formulaQuimica VARCHAR(45) NOT NULL,
  InChlKey VARCHAR(45) NOT NULL,
  codSMILES VARCHAR(45) NOT NULL,
  numCAS INT NOT NULL,
  classificacao VARCHAR(45) NOT NULL,
  Substancia_idSubstancia INT NOT NULL,
  Descritor_idDescritor INT NOT NULL,
  CONSTRAINT pkEstrutura PRIMARY KEY(identifier_InCHl, Substancia_idSubstancia, Descritor_idDescritor),
  CONSTRAINT fkEstrutura_Substancia FOREIGN KEY(Substancia_idSubstancia) REFERENCES BDCAS.Substancia(idSubstancia) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fkEstrutura_Descritor FOREIGN KEY(Descritor_idDescritor) REFERENCES BDCAS.Descritor(idDescritor) ON DELETE CASCADE ON UPDATE CASCADE
  );
  
CREATE TABLE BDCAS.Alimento_has_Substancia (
  Alimento_idAlimento_has_Substancia INT NOT NULL,
  Substancia_idSubstancia_has_Substancia INT NOT NULL,
  CONSTRAINT pkAlimento_has_Substancia PRIMARY KEY(Alimento_idAlimento_has_Substancia),
  CONSTRAINT fkAlimento_has_Substancia FOREIGN KEY(Substancia_idSubstancia_has_Substancia) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fkSubstancia FOREIGN KEY(Substancia_idSubstancia_has_Substancia) REFERENCES BDCAS.Substancia(idSubstancia) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE BDCAS.AcessoAoBanco(
	idAcesso_ao_Banco BDCAS.id NOT NULL,
	dataHora TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
	Usuario_Comum_Usuario_idUsuario int NOT NULL,
	Alimento_idAlimento int NOT NULL,
	Substancia_idSubstancia int NOT NULL,
	CONSTRAINT pkAcessoAoBanco PRIMARY KEY (idAcesso_ao_Banco),
	CONSTRAINT fkAcessoAoBancoUsuario FOREIGN KEY (Usuario_Comum_Usuario_idUsuario) REFERENCES BDCAS.UsuarioComum(idUsuario) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fkAcessoAoBancoAlimento FOREIGN KEY (Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fkAcessoAoBancoSubstancia FOREIGN KEY (Substancia_idSubstancia) REFERENCES BDCAS.Substancia(idSubstancia) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE BDCAS.ManterOBanco(
	idManter_o_Banco BDCAS.id NOT NULL,
	dataHora TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	operacao VARCHAR(10) NOT NULL,
	Usuario_Administrador_Usuario_idUsuario int NOT NULL,
	Alimento_idAlimento int NOT NULL,
	Substancia_idSubstancia int NOT NULL,
	CONSTRAINT pkManterOBanco PRIMARY KEY (idManter_o_Banco),
	CONSTRAINT fkManterOBancoUsuario FOREIGN KEY (Usuario_Administrador_Usuario_idUsuario) REFERENCES BDCAS.UsuarioAdministrador(idUsuario) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fkManterOBancoAlimento FOREIGN KEY (Alimento_idAlimento) REFERENCES BDCAS.Alimento(idAlimento) ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fkManterOBancoSubstancia FOREIGN KEY (Substancia_idSubstancia) REFERENCES BDCAS.Substancia(idSubstancia) ON DELETE CASCADE ON UPDATE CASCADE
);





INSERT INTO BDCAS.Alimento (idAlimento, nomeAlimento) VALUES ('1', 'Maçã');
INSERT INTO BDCAS.Alimento (idAlimento, nomeAlimento) VALUES ('2', 'Banana');
INSERT INTO BDCAS.Alimento (idAlimento, nomeAlimento) VALUES ('3', 'Uva');

INSERT INTO BDCAS.Substancia (idSubstancia) VALUES ('1');
INSERT INTO BDCAS.Substancia (idSubstancia) VALUES ('2');
INSERT INTO BDCAS.Substancia (idSubstancia) VALUES ('3');



INSERT INTO BDCAS.Alimento_has_Substancia (Alimento_idAlimento_has_Substancia, Substancia_idSubstancia_has_Substancia) VALUES ('1', '1');
INSERT INTO BDCAS.Alimento_has_Substancia (Alimento_idAlimento_has_Substancia, Substancia_idSubstancia_has_Substancia) VALUES ('2', '2');
INSERT INTO BDCAS.Alimento_has_Substancia (Alimento_idAlimento_has_Substancia, Substancia_idSubstancia_has_Substancia) VALUES ('3', '3');

INSERT INTO BDCAS.Descritor (idDescritor, h_bond_acceptr, h_bond_donors, massaExata, aLogP, mLogP, LogS, LogD) VALUES ('1', '33', '34', '44', '32', '11', '23', '24');
INSERT INTO BDCAS.Descritor (idDescritor, h_bond_acceptr, h_bond_donors, massaExata, aLogP, mLogP, LogS, LogD) VALUES ('2', '23', '24', '55', '64', '22', '33', '33');
INSERT INTO BDCAS.Descritor (idDescritor, h_bond_acceptr, h_bond_donors, massaExata, aLogP, mLogP, LogS, LogD) VALUES ('3', '44', '55', '44', '11', '21', '22', '23');
INSERT INTO BDCAS.Descritor (idDescritor, h_bond_acceptr, h_bond_donors, massaExata, aLogP, mLogP, LogS, LogD) VALUES ('4', '34', '33', '22', '23', '44', '33', '44');


INSERT INTO BDCAS.Estrutura (identifier_InCHl, formulaQuimica, InChlKey, codSMILES, numCAS, classificacao, Substancia_idSubstancia, Descritor_idDescritor) VALUES ('1', 'H2O', '1234', '3344', '4444', 'class', '1', '1');
INSERT INTO BDCAS.Estrutura (identifier_InCHl, formulaQuimica, InChlKey, codSMILES, numCAS, classificacao, Substancia_idSubstancia, Descritor_idDescritor) VALUES ('2', 'CO2', '2222', '3212', '4321', 'class', '2', '2');
INSERT INTO BDCAS.Estrutura (identifier_InCHl, formulaQuimica, InChlKey, codSMILES, numCAS, classificacao, Substancia_idSubstancia, Descritor_idDescritor) VALUES ('3', 'CO3', '5543', '1234', '2222', 'class', '3', '3');

INSERT INTO BDCAS.Informacoes_Botanicas (idInformacoes_Botanicas, Alimento_idAlimento, subfamilia, tribo, subtribo) VALUES ('1', '1', 'A', 'B', 'C');
INSERT INTO BDCAS.Informacoes_Botanicas (idInformacoes_Botanicas, Alimento_idAlimento, subfamilia, tribo, subtribo) VALUES ('2', '2', 'A', 'B', 'C');
INSERT INTO BDCAS.Informacoes_Botanicas (idInformacoes_Botanicas, Alimento_idAlimento, subfamilia, tribo, subtribo) VALUES ('3', '3', 'A', 'B', 'C');


INSERT INTO BDCAS.LocalizacaoGeografica (localizacaoGeografica, Alimento_idAlimento) VALUES ('l4443323', '1');
INSERT INTO BDCAS.LocalizacaoGeografica (localizacaoGeografica, Alimento_idAlimento) VALUES ('l4543422', '2');
INSERT INTO BDCAS.LocalizacaoGeografica (localizacaoGeografica, Alimento_idAlimento) VALUES ('l4532222', '3');

INSERT INTO BDCAS.Nome_Cientifico_Alimento (Alimento_idAlimento, nomeBinomial, autor, especie, genero, familia, ordem, filo, reino, clado) VALUES ('1', 'Nome 1', 'autor 1', 'especie 1', 'genero 1', 'familia 1', 'ordem 1', 'filo 1', 'reino 1', 'clado 1');
INSERT INTO BDCAS.Nome_Cientifico_Alimento (Alimento_idAlimento, nomeBinomial, autor, especie, genero, familia, ordem, filo, reino, clado) VALUES ('2', 'Nome 2', 'autor 2', 'especie 2', 'genero 2', 'familia 2', 'ordem 2', 'filo 2', 'reino 2', 'clado 2');
INSERT INTO BDCAS.Nome_Cientifico_Alimento (Alimento_idAlimento, nomeBinomial, autor, especie, genero, familia, ordem, filo, reino, clado) VALUES ('3', 'Nome 3', 'autor 3', 'especie 3', 'genero 3', 'familia 3', 'ordem 3', 'filo 3', 'reino 3', 'clado 3');



INSERT INTO BDCAS.Nome_Cientifico_Substancia (idNome_Cientifico_Substancia, nomeComum, nomeSistematico_IUPAC, Substancia_idSubstancia) VALUES ('1', 'nome 1', 'IU1', '1');
INSERT INTO BDCAS.Nome_Cientifico_Substancia (idNome_Cientifico_Substancia, nomeComum, nomeSistematico_IUPAC, Substancia_idSubstancia) VALUES ('2', 'nome 2', 'IU2', '2');
INSERT INTO BDCAS.Nome_Cientifico_Substancia (idNome_Cientifico_Substancia, nomeComum, nomeSistematico_IUPAC, Substancia_idSubstancia) VALUES ('3', 'nome 3', 'IU3', '3');

INSERT INTO BDCAS.ParteAlimentoEstudada (Alimento_idAlimento, parteAlimentoEstudada) VALUES ('1', 'semente');
INSERT INTO BDCAS.ParteAlimentoEstudada (Alimento_idAlimento, parteAlimentoEstudada) VALUES ('2', 'semente');
INSERT INTO BDCAS.ParteAlimentoEstudada (Alimento_idAlimento, parteAlimentoEstudada) VALUES ('3', 'semente');

INSERT INTO BDCAS.Referencia_Bibliografica (idBibliografia, Alimento_idAlimento, autor, dataPublicacao, fontePublicacao) VALUES ('1', '1', 'actor 1', '1970-01-01 00:00:02', 'Wiki');
INSERT INTO BDCAS.Referencia_Bibliografica (idBibliografia, Alimento_idAlimento, autor, dataPublicacao, fontePublicacao) VALUES ('2', '2', 'actor 2', '1990-01-01 00:00:02', 'Wiki');
INSERT INTO BDCAS.Referencia_Bibliografica (idBibliografia, Alimento_idAlimento, autor, dataPublicacao, fontePublicacao) VALUES ('3', '3', 'actor 3', '1870-01-01 00:00:02', 'Wiki');

INSERT INTO BDCAS.Usuario (idUsuario, nomeUsuario) VALUES ('1', 'Thiago');
INSERT INTO BDCAS.Usuario (idUsuario, nomeUsuario) VALUES ('2', 'Marcílio');
INSERT INTO BDCAS.Usuario (idUsuario, nomeUsuario) VALUES ('3', 'Gabriel');

INSERT INTO BDCAS.UsuarioAdministrador (idUsuario, login, senha) VALUES ('1', 'Thiago', 'thiago');
INSERT INTO BDCAS.UsuarioAdministrador (idUsuario, login, senha) VALUES ('2', 'Marcilio', 'marcilio');
INSERT INTO BDCAS.UsuarioAdministrador (idUsuario, login, senha) VALUES ('3', 'Gabriel', 'Gabriel');

INSERT INTO BDCAS.UsuarioComum (idUsuario) VALUES ('1');
INSERT INTO BDCAS.UsuarioComum (idUsuario) VALUES ('2');
INSERT INTO BDCAS.UsuarioComum (idUsuario) VALUES ('3');

INSERT INTO BDCAS.AcessoAoBanco (idAcesso_ao_Banco, dataHora, Usuario_Comum_Usuario_idUsuario, Alimento_idAlimento, Substancia_idSubstancia) VALUES ('1', '1970-01-01 00:00:02', '1', '1', '1');
INSERT INTO BDCAS.AcessoAoBanco (idAcesso_ao_Banco, dataHora, Usuario_Comum_Usuario_idUsuario, Alimento_idAlimento, Substancia_idSubstancia) VALUES ('2', '1970-01-01 00:00:01', '2', '2', '2');
INSERT INTO BDCAS.AcessoAoBanco (idAcesso_ao_Banco, dataHora, Usuario_Comum_Usuario_idUsuario, Alimento_idAlimento, Substancia_idSubstancia) VALUES ('3', '1970-01-01 00:00:03', '3', '3', '3');

INSERT INTO BDCAS.ManterOBanco (idManter_o_Banco, dataHora, operacao, Usuario_Administrador_Usuario_idUsuario, Alimento_idAlimento, Substancia_idSubstancia) VALUES ('1', '1970-01-01 00:00:02', 'Inserir', '1', '1', '1');
INSERT INTO BDCAS.ManterOBanco (idManter_o_Banco, dataHora, operacao, Usuario_Administrador_Usuario_idUsuario, Alimento_idAlimento, Substancia_idSubstancia) VALUES ('2', '1970-01-01 00:00:03', 'Remover', '2', '2', '2');
INSERT INTO BDCAS.ManterOBanco (idManter_o_Banco, dataHora, operacao, Usuario_Administrador_Usuario_idUsuario, Alimento_idAlimento, Substancia_idSubstancia) VALUES ('3', '1970-01-01 00:00:04', 'Editar', '3', '3', '3');

ALTER TABLE BDCAS.Substancia ADD CONSTRAINT check_id_sub CHECK (idSubstancia > 0);
ALTER TABLE BDCAS.Alimento ADD CONSTRAINT check_id_alim CHECK (idAlimento > 0);
ALTER TABLE BDCAS.Descritor ADD CONSTRAINT check_id_des CHECK (idDescritor > 0);
ALTER TABLE BDCAS.Estrutura ADD CONSTRAINT check_id_es CHECK (identifier_InCHl > 0);
ALTER TABLE BDCAS.Informacoes_Botanicas ADD CONSTRAINT check_id_ib CHECK (idInformacoes_Botanicas > 0);
ALTER TABLE BDCAS.Nome_Cientifico_Substancia ADD CONSTRAINT check_id_ncs CHECK (idNome_Cientifico_Substancia > 0);
ALTER TABLE BDCAS.Referencia_Bibliografica ADD CONSTRAINT check_id_rb CHECK (idBibliografia > 0);
ALTER TABLE BDCAS.Usuario ADD CONSTRAINT check_id_u CHECK (idUsuario > 0);
ALTER TABLE BDCAS.AcessoAoBanco ADD CONSTRAINT check_id_aab CHECK (idAcesso_ao_Banco > 0);
ALTER TABLE BDCAS.ManterOBanco ADD CONSTRAINT check_id_mob CHECK (idManter_o_Banco > 0);

ALTER TABLE BDCAS.ManterOBanco ADD CONSTRAINT check_operacao CHECK (operacao IN ('Inserir','Editar','Remover'));

--1
SELECT * FROM BDCAS.Estrutura WHERE BDCAS.Estrutura.formulaquimica = 'CO2';
--2
SELECT alimento.nomeAlimento, clas.subfamilia, clas.tribo, clas.subtribo FROM BDCAS.Alimento alimento JOIN BDCAS.Informacoes_Botanicas clas ON (alimento.idAlimento = clas.Alimento_idAlimento);
--3
SELECT e.formulaquimica, e.InChlKey, e.codSMILES, e.numCAS FROM BDCAS.Substancia s JOIN BDCAS.Estrutura e ON (s.idSubstancia = e.Substancia_idSubstancia) JOIN BDCAS.Descritor d ON (d.idDescritor = e.Descritor_idDescritor) WHERE d.mLogP > (SELECT min(mLogP) FROM BDCAS.Descritor) ORDER BY s.idSubstancia DESC
--4
SELECT avg(des.massaexata) FROM BDCAS.Estrutura es RIGHT JOIN BDCAS.Descritor des ON (es.Descritor_idDescritor = des.idDescritor);
--5
SELECT a.nomeAlimento FROM BDCAS.Nome_Cientifico_Alimento nca JOIN BDCAS.Alimento a ON (a.idAlimento = nca.Alimento_idAlimento) JOIN BDCAS.LocalizacaoGeografica  lg ON (a.idAlimento = lg.Alimento_idAlimento) WHERE lg.localizacaoGeografica = (SELECT max(localizacaoGeografica) FROM BDCAS.LocalizacaoGeografica)

--6
SELECT * FROM BDCAS.alimento JOIN BDCAS.alimento_has_substancia ON(BDCAS.alimento.idalimento = BDCAS.alimento_has_substancia.alimento_idalimento_has_substancia) NATURAL JOIN BDCAS.substancia JOIN BDCAS.nome_cientifico_substancia ON(BDCAS.nome_cientifico_substancia.idnome_cientifico_substancia = BDCAS.substancia.idsubstancia);
--7
SELECT count(BDCAS.usuario.idusuario) AS qtdUsuario,BDCAS.usuario.nomeusuario FROM BDCAS.usuario JOIN BDCAS.usuarioadministrador USING(idUsuario) GROUP BY BDCAS.usuario.idusuario;
--8
SELECT count(DISTINCT BDCAS.usuario.idusuario) AS qtdUsuario,BDCAS.usuario.nomeusuario  FROM BDCAS.usuario  NATURAL JOIN  BDCAS.usuariocomum NATURAL JOIN BDCAS.acessoaobanco GROUP BY BDCAS.usuario.idusuario HAVING BDCAS.usuario.nomeusuario= 'Thiago';
--9
CREATE OR REPLACE FUNCTION get_alimento (nAlimento VARCHAR) 
 RETURNS TABLE (
 Alimento VARCHAR
) 
AS $$
BEGIN
 RETURN QUERY SELECT
 
 BDCAS.alimento.nomealimento
 FROM
 BDCAS.alimento
 WHERE
 BDCAS.alimento.nomealimento LIKE nAlimento ;
END; $$ 
 
LANGUAGE 'plpgsql';

SELECT * FROM get_alimento('Ma%');

--10
SELECT * FROM BDCAS.alimento WHERE idalimento = (SELECT avg(idalimento) FROM BDCAS.alimento);