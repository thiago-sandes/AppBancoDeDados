/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bdcas;


import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import net.proteanit.sql.DbUtils;



public class BDCAS {
	
   public Connection conexao = null;
	
   public BDCAS() {
      try{
         //Carregar driver JDBC do postgress
         Class.forName("org.postgresql.Driver"); 
         System.out.println("Carregou");
      } catch (ClassNotFoundException ex){ex.printStackTrace();}
   }
   
   public void setConnection() throws SQLException{
	   String host = "10.27.159.214:5432";
	   String db = "BDCAS";
	   String url = "jdbc:postgresql://" + host + "/" + db;
	   String user = "aluno1";
	   String senha = "aluno1";
	   conexao = DriverManager.getConnection(url, user, senha);
	   System.out.println("Criou a conexão");
   }
   
   public void InsercaoStatment(Connection conexao, String sql) throws SQLException{
	   Statement comando = conexao.createStatement();
	   System.out.println("Executar Insercao: " + sql);
           
        try{   
           comando.executeUpdate(sql);
           	
	   comando.close();
        }catch(Exception e){
           JOptionPane.showMessageDialog(null, "Erro: " + "Algo errado. Tente da maneira correta.");
 
           comando.close();
        }
    }
   
   public void DeleteStatment(Connection conexao, String sql) throws SQLException{
           Statement comando = conexao.createStatement();
           System.out.println("Executar Delete: " + sql);

       
           try{   
                comando.executeUpdate(sql);
           
                comando.close();
           }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Erro: " + "Algo errado. Tente da maneira correta.");

                comando.close();
           }
           
    }
   
   
   public void comandoConsulta(Connection conexao, String sql) throws SQLException{
    try{   Statement comando = conexao.createStatement();
	   System.out.println("Executar consulta: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   ResultSetMetaData rsm = resultado.getMetaData();
           
           JFrame frame = new JFrame("Consulta");
           JTable tabela = new JTable();
           JScrollPane scrollPane = new JScrollPane();

           scrollPane.setViewportView(tabela);
           scrollPane.setBounds(283, 43, 302, 114);

           frame.getContentPane().add(scrollPane); 
           frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
           // frame.pack();
           
           frame.setSize(400, 400);
           
           frame.setVisible(true);
           
           
           tabela.setModel(DbUtils.resultSetToTableModel(resultado));
           
           int countTable = 0;
	   while(resultado.next()){
		   for(int i = 1; i<=rsm.getColumnCount(); i++){
			   if (countTable == 0){
                               String tableName = rsm.getTableName(i); 
                               System.out.println("Nome da tabela: " +tableName + "\t");
                               System.out.println("");
                              
                               countTable ++;
                           }
                           
                           String columnName = rsm.getColumnName(i);  
                           String campo = resultado.getString(i);
			   System.out.println(columnName + "\t");
                           System.out.println(campo + "\t");
		   }
		   System.out.println();
	   }
           countTable = 0;
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, "Erro: " + "Algo errado. Tente da maneira correta.");
 
    }       
          
   }
   
   
   public void exemploConsultaStatmentMeta(Connection conexao) throws SQLException{
	   String sql = "SELECT * FROM universidade.professor WHERE departamento = 'DCOMP'";
	   Statement comando = conexao.createStatement();
	   System.out.println("Executar consulta: " + sql);
	   ResultSet resultado = comando.executeQuery(sql);
	   ResultSetMetaData rsm = resultado.getMetaData();
	   while(resultado.next()){
		   for(int i = 1; i<=rsm.getColumnCount(); i++){
			   String campo = resultado.getString(i);
			   System.out.print(campo + "\t");
		   }
		   System.out.println();
	   }
   }
   


   public static void main(String[] args) {
      BDCAS conn = new BDCAS();
      String op;
      String sql;
      
	   
      try{
          conn.setConnection();
          
          op = JOptionPane.showInputDialog("Digite qual opção desejada para comando sql:  \n 1-Select \n 2-Insert \n 3-Delete");
          
          if(op == null)
              System.exit(0);

            if(op.equals("1")){

                  sql = JOptionPane.showInputDialog("Digite um comando sql");
                  System.out.println(sql);

                  if(sql == null){

                  }else{
                        conn.comandoConsulta(conn.conexao, sql);
                  }


                  //conn.exemploConsultaStatment(conn.conexao);
                  //teste.exemploConsultaPreparedStatment(teste.conexao);
                  conn.conexao.close();


            }else{

                if(op.equals("2")){
                  sql = JOptionPane.showInputDialog("Digite um comando sql");
                  System.out.println(sql);

                  if(sql == null){

                  }else{
                        conn.InsercaoStatment(conn.conexao, sql);
                  }
                }else{

                    if(op.equals("3")){
                        sql = JOptionPane.showInputDialog("Digite um comando sql");
                        System.out.println(sql);
                        
                        if(sql == null){

                        }else{
                            conn.DeleteStatment(conn.conexao, sql);
                        }

                        conn.conexao.close();

                    }else{
                        JOptionPane.showMessageDialog(null, "Erro: " + "Algo errado. Tente da maneira correta.");                        
                    }

                }



            }


      } catch(SQLException ex) {ex.printStackTrace();}
   }
}
