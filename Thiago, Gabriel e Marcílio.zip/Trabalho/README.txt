INSTRU��ES PARA PROGRAMA

Simples: Tr�s op��es: 1 - Executa consulta, 2 - Insere no banco de dados e 3 - Deleta do banco de dados.

Foi criado banco de dados BDCAS para executar aplica��o.

Adicionar duas bibliotecas .jar ao projeto caso necessite do c�digo em IDE.

Executar Scripts para cria��o de banco de dados BDCAS que est� junto com esse arquivo na mesma pasta.

Comando para testar(seguir ordem e verificar com SELECT):

BDCAS.localizacaogeografica;

INSERT INTO BDCAS.localizacaogeografica VALUES('11111111', 4);

BDCAS.localizacaogeografica;

SELECT FROM BDCAS.partealimentoestudada;

DELETE FROM BDCAS.partealimentoestudada;

SELECT BDCAS.partealimentoestudada;